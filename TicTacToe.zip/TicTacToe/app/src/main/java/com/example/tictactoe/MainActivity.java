package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.nfc.Tag;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //0-cross & 1-zero
    int press = 0;
    boolean store = true;
    int arr[] = {2,2,2,2,2,2,2,2,2};
    int winPos[][] = {{0,1,2} , {3,4,5} , {6,7,8} ,
            {0,3,6} , {1,4,7} , {2,5,8} , {0,4,8} , {2,4,6}};
    public void buttonPressed(View view){
        ImageView centre = (ImageView) view;
        centre.setTranslationY(-1000f);
        int var = Integer.parseInt(centre.getTag().toString());
        if(arr[var] == 2 && store){
            if(press == 0)
            {
                centre.setImageResource(R.drawable.cross1);
                press = 1;
                arr[var] = press;
            }
            else{
                centre.setImageResource(R.drawable.zero1);
                press = 0;
                arr[var] = press;
            }

            //centre.animate().translationYBy(1000f).setDuration(300);
        }
        centre.animate().translationYBy(1000f).setDuration(300);

        for(int[] check : winPos){
            if(arr[check[0]] == arr[check[1]] && arr[check[1]] == arr[check[2]] && arr[check[0]] != 2){
                System.out.println(arr[check[0]]);
                store = false;
                String get = "zero";

                if(arr[check[0]] == 1)
                    get = "cross";


                //Toast.makeText(MainActivity.this, arr[check[0]] + " won", Toast.LENGTH_LONG).show();

                //winner

                TextView getWinner = (TextView) findViewById(R.id.winner);
                getWinner.setVisibility(View.VISIBLE);
                getWinner.setText(get+" has won");
                Button play = (Button) findViewById(R.id.button2);
                play.setVisibility(View.VISIBLE);
            }
            else {
                boolean gameIsover = true;
                for(int next : arr){
                    if(next == 2)
                        gameIsover = false;
                }
                if(gameIsover && arr[check[0]] != arr[check[1]] && arr[check[1]] != arr[check[2]]){
                    TextView getWinner = (TextView) findViewById(R.id.winner);
                    getWinner.setVisibility(View.VISIBLE);
                    getWinner.setText("match draw");
                    Button play = (Button) findViewById(R.id.button2);
                    play.setVisibility(View.VISIBLE);
                }
            }
        }
    }

    public void replay(View view){
        TextView getWinner = (TextView) findViewById(R.id.winner);
        getWinner.setVisibility(View.INVISIBLE);
        Button play = (Button) findViewById(R.id.button2);
        play.setVisibility(View.INVISIBLE);
        store = true;
        for(int i=0; i<arr.length; i++){
            arr[i] = 2;
        }

        LinearLayout l1 = (LinearLayout) findViewById(R.id.linearLayout);
        for(int i=0; i<l1.getChildCount(); i++){
            ((ImageView) l1.getChildAt(i)).setImageResource(0);
        }
        LinearLayout l2 = (LinearLayout) findViewById(R.id.linearLayout2);
        for(int i=0; i<l2.getChildCount(); i++){
            ((ImageView) l2.getChildAt(i)).setImageResource(0);
        }
        LinearLayout l3 = (LinearLayout) findViewById(R.id.linearLayout3);
        for(int i=0; i<l3.getChildCount(); i++){
            ((ImageView) l3.getChildAt(i)).setImageResource(0);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}